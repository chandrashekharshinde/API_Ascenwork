﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace glassRUNService.WebApi.ManageInventory.DTO
{
    public class ReasonCodeDTO
    {
        public string ReasonCode { get; set; }
        public string ReasonName { get; set; }
    }
}
